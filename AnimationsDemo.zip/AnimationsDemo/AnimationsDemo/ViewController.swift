//
//  ViewController.swift
//  AnimationsDemo
//
//  Created by Panuganti,Sirisha on 10/24/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var happyOL: UIButton!
    
    
    @IBOutlet weak var sadOL: UIButton!
    
    @IBOutlet weak var angryOL: UIButton!
    
    @IBOutlet weak var shakemeOL: UIButton!
    
    
    @IBOutlet weak var showOL: UIButton!
    
    @IBOutlet weak var imageOL: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        showOL.isEnabled = true
    }


    @IBAction func happy(_ sender: Any) {
        updateandAnimate("happy")
        
    }
    @IBAction func sad(_ sender: Any) {
        updateandAnimate("sad")
    }
    
    @IBAction func angry(_ sender: Any) {
        updateandAnimate("angry")
    }
    
    @IBAction func shakeme(_ sender: Any) {
        var width = imageOL.frame.width
        width += 40
        var height = imageOL.frame.width
        height += 40
        
        var x = imageOL.frame.origin.x - 20
        var y = imageOL.frame.origin.y - 20
        
        var largeFrame = CGRect(x: x, y: y,width: width,height: height)
        
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.4,initialSpringVelocity: 100, animations:{
            self.imageOL.frame = largeFrame
            
        })
    }
    @IBAction func show(_ sender: Any) {
        
       // happyOL.frame.origin
        UIView.animate(withDuration: 1, animations:{
            self.imageOL.center.x = self.view.center.x
            self.happyOL.center.x = self.view.center.x
            self.sadOL.center.x = self.view.center.x
            self.angryOL.center.x = self.view.center.x
            self.shakemeOL.center.x = self.view.center.x
            
        })
        showOL.isEnabled = false
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        //to make it appear
        
        //move the image view outside of the screen view
        
        imageOL.frame.origin.x = view.frame.maxX
        
        
        //move other components outside of the screen
        
        happyOL.frame.origin.x = view.frame.width
        sadOL.frame.origin.x = view.frame.width
        angryOL.frame.origin.x = view.frame.width
        shakemeOL.frame.origin.x = view.frame.width
    }
    
    func updateandAnimate(_ imageName: String){
        //make the current image as opaque(aplha = 0)
        
        UIView.animate(withDuration:1,animations:{
            self.imageOL.alpha = 0
        })
        //assign the new image with animation and make it as transparent (alpha is 1)
        
        UIView.animate(withDuration: 0.5, animations: {
            self.imageOL.alpha = 1
            self.imageOL.image = UIImage(named: imageName)
                       })
        
    }
}

